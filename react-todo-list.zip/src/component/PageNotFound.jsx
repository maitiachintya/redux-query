import React from 'react'

const PageNotFound = () => {
  return (
    <div>
      <h1 >404! Sorry Page Not Found Here...</h1>
    </div>
  )
}

export default PageNotFound
