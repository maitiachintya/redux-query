import React from 'react'
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom'
import Header from '../layout/Header'
import Home from '../component/Home'
import PageNotFound from '../component/PageNotFound'
// import Footer from '../layout/Footer'
import TodoView from '../component/todo/view/TodoView'

const Routing = () => {
    return (
        <div>
            <Router>
                <Header />
                <Routes>
                    <Route path='' element={<Home />}></Route>
                    <Route path='todoview-page' element={<TodoView />}></Route>
                    {/* <Route path='user-page/details/:id' element={<UserDetails />}></Route> */}
                    <Route path='*' element={<PageNotFound />}></Route>
                </Routes>
                {/* <Footer /> */}
            </Router>
        </div>
    )
}

export default Routing